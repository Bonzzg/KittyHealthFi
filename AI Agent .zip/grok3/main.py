import os
import logging
import asyncio
import traceback
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import aiohttp
from dotenv import load_dotenv
from tenacity import retry, stop_after_attempt, wait_fixed, retry_if_exception_type
from fastapi.responses import JSONResponse
import uvicorn

# 设置日志
logging.basicConfig(
    filename='D:/jiayi/grok3/app.log',
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = FastAPI()

# CORS 配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:*",  # 开发环境通配符，生产环境需移除
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "Accept", "X-Requested-With"],
)

# 加载环境变量
try:
    load_dotenv('D:/jiayi/grok3/.env')
    GROK_API_KEY = os.getenv("GROK_API_KEY")
    if not GROK_API_KEY:
        logger.error("GROK_API_KEY 未在 .env 文件中设置")
        raise EnvironmentError("GROK_API_KEY 未设置")
except Exception as e:
    logger.error(f"加载环境变量失败: {str(e)}, 堆栈: {traceback.format_exc()}")
    raise


class ChatRequest(BaseModel):
    user_input: str
    expert_type: str
    session_id: str | None = None
    history: list[dict] = []


# 输入验证
def validate_input(prompt: str, expert_type: str):
    if not prompt.strip():
        logger.error("输入提示为空")
        raise HTTPException(status_code=400, detail="用户输入不能为空")
    if expert_type not in ['medical', 'insurance']:
        logger.error(f"无效的专家类型: {expert_type}")
        raise HTTPException(status_code=400, detail="无效的专家类型，仅支持 'medical' 或 'insurance'")


# 调用 Grok API
@retry(
    stop=stop_after_attempt(3),
    wait=wait_fixed(2),
    retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
    before_sleep=lambda retry_state: logger.debug(f"重试 {retry_state.attempt_number}/3")
)
async def call_grok_api(prompt: str, history: list[dict], expert_type: str):
    validate_input(prompt, expert_type)

    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
        headers = {
            "Authorization": f"Bearer {GROK_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "grok-3",
            "messages": [
                {
                    "role": "system",
                    "content": (
                        f"你是{'医疗问诊专家' if expert_type == 'medical' else '保险资产配置专家'}。"
                        "请根据用户输入提供专业、亲切的回答，使用 Markdown 格式，包含标题、列表和加粗。"
                    )
                },
                *history,
                {"role": "user", "content": prompt}
            ]
        }
        logger.debug(f"发送 Grok API 请求: {payload}")
        try:
            async with session.post("https://api.x.ai/v1/chat/completions", headers=headers, json=payload) as response:
                response_text = await response.text()
                logger.debug(f"Grok API 原始响应: {response_text}")
                if response.status != 200:
                    logger.error(f"Grok API 请求失败，状态码: {response.status}, 错误: {response_text}")
                    raise HTTPException(status_code=response.status, detail=f"Grok API 请求失败: {response_text}")
                try:
                    data = await response.json()
                except ValueError as e:
                    logger.error(
                        f"Grok API 响应解析失败: {str(e)}, 响应内容: {response_text}, 堆栈: {traceback.format_exc()}")
                    raise HTTPException(status_code=500, detail=f"Grok API 响应解析失败: {str(e)}")
                if not data.get("choices") or not data["choices"][0].get("message"):
                    logger.error(f"Grok API 响应格式错误: {data}")
                    raise HTTPException(status_code=500, detail=f"Grok API 响应格式错误: {data}")
                logger.debug(f"Grok API 响应: {data}")
                return data["choices"][0]["message"]["content"]
        except aiohttp.ClientError as e:
            logger.error(f"Grok API 连接错误: {str(e)}, 请求: {payload}, 堆栈: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Grok API 连接错误: {str(e)}")
        except Exception as e:
            logger.error(f"Grok API 未知错误: {str(e)}, 请求: {payload}, 堆栈: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Grok API 未知错误: {str(e)}")


@app.get("/health")
async def health_check():
    logger.debug("收到 /health 请求")
    return {"status": "ok", "message": "后端服务运行正常"}


@app.options("/api/chat")
async def options_chat():
    logger.debug("收到 OPTIONS /api/chat 请求")
    return JSONResponse(content={"status": "ok"})


@app.post("/api/chat")
async def chat(request: ChatRequest):
    logger.debug(f"收到 /api/chat 请求: {request.model_dump()}")
    try:
        response = await asyncio.wait_for(
            call_grok_api(request.user_input, request.history, request.expert_type),
            timeout=15
        )
        logger.debug(f"返回 /api/chat 响应: {response}")
        return {"response": response}
    except asyncio.TimeoutError:
        logger.error("Grok API 调用超时")
        raise HTTPException(status_code=504, detail="Grok API 调用超时")
    except HTTPException as e:
        logger.error(f"HTTP 错误: {str(e)}, 堆栈: {traceback.format_exc()}")
        raise
    except Exception as e:
        logger.error(f"服务器错误: {str(e)}, 堆栈: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")


@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    logger.debug(f"收到文件上传请求: {file.filename}")
    try:
        content = await file.read()
        if file.filename.endswith('.txt'):
            text = content.decode('utf-8')
        elif file.filename.endswith('.pdf'):
            text = "PDF 文件解析暂不支持"
        elif file.filename.endswith(('.jpg', '.jpeg', '.png')):
            text = "图像文件解析暂不支持"
        else:
            logger.error(f"不支持的文件格式: {file.filename}")
            raise HTTPException(status_code=400, detail="不支持的文件格式")
        prompt = f"用户上传文件内容: {text}. 请提供相关建议，使用 Markdown 格式，包含标题、列表和加粗。"
        response = await asyncio.wait_for(
            call_grok_api(prompt, [], 'medical'),
            timeout=15
        )
        logger.debug(f"文件上传处理成功: {response}")
        return {"response": response}
    except asyncio.TimeoutError:
        logger.error("文件上传处理超时")
        raise HTTPException(status_code=504, detail="文件上传处理超时")
    except HTTPException as e:
        logger.error(f"HTTP 错误: {str(e)}, 堆栈: {traceback.format_exc()}")
        raise
    except Exception as e:
        logger.error(f"文件上传处理失败: {str(e)}, 堆栈: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"文件处理失败: {str(e)}")


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
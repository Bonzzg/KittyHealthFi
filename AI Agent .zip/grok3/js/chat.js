document.addEventListener('DOMContentLoaded', () => {
    const chatBox = document.getElementById('chat-box');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const fileUpload = document.getElementById('file-upload');
    const insuranceFormBtn = document.getElementById('insurance-form-btn');
    const medicalFormBtn = document.getElementById('medical-form-btn');
    const insuranceFormModal = document.getElementById('insurance-form-modal');
    const medicalFormModal = document.getElementById('medical-form-modal');
    const insuranceFormContent = document.getElementById('insurance-form-content');
    const medicalFormContent = document.getElementById('medical-form-content');
    const insuranceFormClose = document.getElementById('insurance-form-close');
    const medicalFormClose = document.getElementById('medical-form-close');
    const insuranceFormError = document.getElementById('insurance-form-error');
    const medicalFormError = document.getElementById('medical-form-error');
    const newSessionBtn = document.getElementById('new-session-btn');
    const expertTitle = document.getElementById('expert-title');
    const expertOptions = document.querySelectorAll('.expert-option');
    let currentSessionId = null;
    let currentExpert = 'medical';
    let awaitingInsuranceClarification = false;
    let isSubmitting = false;
    let isModalOpening = false;

    // 初始化
    const urlParams = new URLSearchParams(window.location.search);
    const initialExpert = urlParams.get('expert') === 'insurance' ? 'insurance' : 'medical';
    currentExpert = initialExpert;
    updateExpertSelection();
    updateExpertTitle();
    updateFormButtonVisibility();
    updateSessionList();
    gsap.from('.navbar', { opacity: 0, y: -20, duration: 0.4, ease: 'power2.out' });
    gsap.from('.sidebar', { opacity: 0, x: -20, duration: 0.4, ease: 'power2.out' });
    gsap.from('.chat-container', { opacity: 0, x: 20, duration: 0.4, ease: 'power2.out' });
    gsap.from('.placeholder', { opacity: 0, y: 10, duration: 0.4, ease: 'power2.out', delay: 0.2 });

    // 检查后端健康状态
    async function checkBackendHealth() {
        try {
            const response = await fetch('http://localhost:8000/health', { method: 'GET' });
            if (!response.ok) throw new Error(`后端健康检查失败，状态: ${response.status}`);
            const data = await response.json();
            console.log('后端健康检查:', data);
            return true;
        } catch (error) {
            console.error('后端健康检查失败:', error);
            return false;
        }
    }

    // 更新专家标题
    function updateExpertTitle() {
        if (expertTitle) {
            expertTitle.textContent = currentExpert === 'medical' ? '医疗问诊专家' : '保险资产配置专家';
        }
    }

    // 更新专家选择状态
    function updateExpertSelection() {
        expertOptions.forEach(option => {
            option.classList.toggle('selected', option.dataset.expert === currentExpert);
        });
    }

    // 更新问卷/报告按钮可见性
    function updateFormButtonVisibility() {
        if (insuranceFormBtn) insuranceFormBtn.style.display = currentExpert === 'insurance' ? 'block' : 'none';
        if (medicalFormBtn) medicalFormBtn.style.display = currentExpert === 'medical' ? 'block' : 'none';
    }

    // 清理事件监听器
    function clearEventListeners(element) {
        if (element) {
            const clonedElement = element.cloneNode(true);
            element.parentNode.replaceChild(clonedElement, element);
            return clonedElement;
        }
        return element;
    }

    // 专家选择切换
    expertOptions.forEach(option => {
        option.addEventListener('click', () => {
            if (isSubmitting || isModalOpening) return;
            currentExpert = option.dataset.expert;
            awaitingInsuranceClarification = false;
            updateExpertSelection();
            updateExpertTitle();
            updateFormButtonVisibility();
            // 清理按钮事件监听器
            insuranceFormBtn = clearEventListeners(insuranceFormBtn);
            medicalFormBtn = clearEventListeners(medicalFormBtn);
            insuranceFormClose = clearEventListeners(insuranceFormClose);
            medicalFormClose = clearEventListeners(medicalFormClose);
            insuranceFormContent = clearEventListeners(insuranceFormContent);
            medicalFormContent = clearEventListeners(medicalFormContent);
            // 重新绑定事件
            bindFormEvents();
            startNewSession();
        });
    });

    // 绑定表单事件
    function bindFormEvents() {
        if (insuranceFormBtn) {
            insuranceFormBtn.addEventListener('click', openInsuranceForm);
        }
        if (medicalFormBtn) {
            medicalFormBtn.addEventListener('click', openMedicalForm);
        }
        if (insuranceFormClose) {
            insuranceFormClose.addEventListener('click', () => {
                forceCloseModal(insuranceFormModal, insuranceFormContent, insuranceFormError);
            });
        }
        if (medicalFormClose) {
            medicalFormClose.addEventListener('click', () => {
                forceCloseModal(medicalFormModal, medicalFormContent, medicalFormError);
            });
        }
        if (insuranceFormContent) {
            insuranceFormContent.addEventListener('submit', submitInsuranceForm);
        }
        if (medicalFormContent) {
            medicalFormContent.addEventListener('submit', submitMedicalForm);
        }
    }

    // 初始化表单事件
    bindFormEvents();

    // 新建会话
    newSessionBtn.addEventListener('click', () => {
        startNewSession();
    });

    // 发送消息
    sendBtn.addEventListener('click', () => {
        if (!isSubmitting && !isModalOpening) sendMessage();
    });
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey && !isSubmitting && !isModalOpening) {
            e.preventDefault();
            sendMessage();
        }
    });

    async function sendMessage() {
        const input = userInput.value.trim();
        if (!input) return;

        isSubmitting = true;
        sendBtn.disabled = true;

        const placeholder = chatBox.querySelector('.placeholder');
        if (placeholder) placeholder.remove();

        appendMessage('user', input);
        userInput.value = '';
        userInput.style.height = '120px';
        userInput.focus();

        if (!(await checkBackendHealth())) {
            appendMessage('assistant', '错误：后端服务（http://localhost:8000）未响应，请检查 Uvicorn 是否运行或查看 app.log。');
            isSubmitting = false;
            sendBtn.disabled = false;
            return;
        }

        try {
            let prompt = input;
            if (currentExpert === 'insurance' && !awaitingInsuranceClarification) {
                prompt = `根据用户输入：${input}，请按以下步骤生成个性化保险推荐，使用 Markdown 格式：
### 1. 信息确认
- 确认用户输入的主要需求
- 询问预算范围、风险偏好和家庭状况（如“您的预算范围是多少？偏好低风险还是高回报？是否有家庭成员需要保障？”）
### 2. 初步推荐
- 提供至少两种保险产品（如寿险、医疗险），说明适合的理由
### 3. 下一步建议
- 提供购买或咨询建议
语气亲切，强调“为您量身定制”。`;
                awaitingInsuranceClarification = true;
            } else if (currentExpert === 'insurance' && awaitingInsuranceClarification) {
                prompt = `用户提供的额外信息：${input}，结合之前的问卷数据，提供个性化的保险推荐，包含以下内容，使用 Markdown 格式：
### 1. 信息整合
- 总结用户提供的所有信息
### 2. 保险推荐
- 推荐至少两种保险产品（如寿险、医疗险），说明适合的理由
### 3. 下一步建议
- 提供购买或咨询建议
语气亲切，强调“为您量身定制”。`;
                awaitingInsuranceClarification = false;
            } else if (currentExpert === 'medical') {
                prompt = `用户症状描述：${input}。请模拟专业医生问诊流程，使用 Markdown 格式，输出以下结构：
### 1. 症状澄清
- 提出具体问题以澄清症状（如“症状的严重程度如何？是否有伴随症状如发热或恶心？”）
### 2. 可能性排除
- 列出至少两种可能的疾病，并说明排除理由（如“排除急性阑尾炎，因为无右下腹痛”）
### 3. 初步诊断
- 提供可能的诊断，说明依据
### 4. 建议
- 提供治疗建议或进一步检查建议
语气专业但亲切，避免使用过于复杂的医学术语。`;
            }
            const response = await callGrokApi(prompt, currentExpert, currentSessionId);
            appendMessage('assistant', response);
            saveChatHistory(input, response, currentExpert);
            updateSessionList();
        } catch (error) {
            appendMessage('assistant', `错误：消息发送失败 - ${error.message}. 请检查后端服务（http://localhost:8000）日志或网络连接。`);
            console.error('发送消息失败:', error);
        } finally {
            isSubmitting = false;
            sendBtn.disabled = false;
        }
    }

    // 文件上传
    fileUpload.addEventListener('change', async () => {
        const file = fileUpload.files[0];
        if (!file || isSubmitting || isModalOpening) return;

        isSubmitting = true;

        const placeholder = chatBox.querySelector('.placeholder');
        if (placeholder) placeholder.remove();

        const formData = new FormData();
        formData.append('file', file);

        if (!(await checkBackendHealth())) {
            appendMessage('assistant', '错误：后端服务（http://localhost:8000）未响应，请检查 Uvicorn 是否运行或查看 app.log。');
            isSubmitting = false;
            return;
        }

        try {
            const response = await fetch('http://localhost:8000/api/upload', {
                method: 'POST',
                body: formData
            });
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP错误！状态: ${response.status}. 可能是文件格式不支持或后端服务未响应。`);
            }
            const data = await response.json();
            appendMessage('assistant', data.response);
            saveChatHistory(`上传文件: ${file.name}`, data.response, currentExpert);
            updateSessionList();
            fileUpload.value = '';
        } catch (error) {
            appendMessage('assistant', `错误：文件上传失败 - ${error.message}. 请检查网络或文件格式（支持 .txt, .pdf, .jpg, .jpeg, .png）。`);
            console.error('文件上传失败:', error);
        } finally {
            isSubmitting = false;
        }
    });

    // 显示保险问卷模态框
    function openInsuranceForm() {
        if (isSubmitting || isModalOpening) return;
        isModalOpening = true;
        insuranceFormBtn.disabled = true;
        setTimeout(() => {
            try {
                if (insuranceFormModal) insuranceFormModal.style.display = 'flex';
                gsap.from('.modal-content', {
                    opacity: 0,
                    y: 20,
                    duration: 0.3,
                    ease: 'power2.out',
                    onComplete: () => {
                        isModalOpening = false;
                        insuranceFormBtn.disabled = false;
                        document.getElementById('form-age')?.focus();
                    }
                });
            } catch (e) {
                console.error('打开保险问卷模态框失败:', e);
                if (insuranceFormModal) insuranceFormModal.style.display = 'flex';
                isModalOpening = false;
                insuranceFormBtn.disabled = false;
                document.getElementById('form-age')?.focus();
            }
        }, 100);
    }

    // 显示医疗报告模态框
    function openMedicalForm() {
        if (isSubmitting || isModalOpening) return;
        isModalOpening = true;
        medicalFormBtn.disabled = true;
        setTimeout(() => {
            try {
                if (medicalFormModal) medicalFormModal.style.display = 'flex';
                gsap.from('.modal-content', {
                    opacity: 0,
                    y: 20,
                    duration: 0.3,
                    ease: 'power2.out',
                    onComplete: () => {
                        isModalOpening = false;
                        medicalFormBtn.disabled = false;
                        document.getElementById('med-form-age')?.focus();
                    }
                });
            } catch (e) {
                console.error('打开医疗报告模态框失败:', e);
                if (medicalFormModal) medicalFormModal.style.display = 'flex';
                isModalOpening = false;
                medicalFormBtn.disabled = false;
                document.getElementById('med-form-age')?.focus();
            }
        }, 100);
    }

    // 强制关闭模态框
    function forceCloseModal(modal, form, error) {
        try {
            if (modal) modal.style.display = 'none';
            if (form) form.reset();
            if (error) error.style.display = 'none';
            userInput.focus();
            isSubmitting = false;
            isModalOpening = false;
            const submitBtn = form?.querySelector('button[type="submit"]');
            if (submitBtn) submitBtn.disabled = false;
        } catch (e) {
            console.error('关闭模态框失败:', e);
        }
    }

    // 关闭模态框（带动画）
    function closeModal(modal, form, error) {
        try {
            gsap.to('.modal-content', {
                opacity: 0,
                y: 20,
                duration: 0.3,
                ease: 'power2.in',
                onComplete: () => {
                    forceCloseModal(modal, form, error);
                }
            });
        } catch (e) {
            console.error('GSAP 动画错误:', e);
            forceCloseModal(modal, form, error);
        }
    }

    // 提交保险问卷
    async function submitInsuranceForm(e) {
        e.preventDefault();
        if (isSubmitting || isModalOpening) return;

        isSubmitting = true;
        const submitBtn = document.getElementById('submit-insurance-form-btn');
        if (submitBtn) submitBtn.disabled = true;
        if (insuranceFormError) insuranceFormError.style.display = 'none';

        const formData = {
            age: parseInt(document.getElementById('form-age')?.value) || 0,
            income: parseFloat(document.getElementById('form-income')?.value) || 0,
            health_conditions: document.getElementById('form-health')?.value.trim() || '',
            insurance_needs: document.getElementById('form-needs')?.value.trim() || ''
        };

        if (!formData.age || !formData.income || !formData.health_conditions || !formData.insurance_needs) {
            if (insuranceFormError) {
                insuranceFormError.textContent = '请填写所有字段';
                insuranceFormError.style.display = 'block';
                gsap.from('#insurance-form-error', { opacity: 0, y: 10, duration: 0.3, ease: 'power2.out' });
            }
            isSubmitting = false;
            if (submitBtn) submitBtn.disabled = false;
            return;
        }

        const placeholder = chatBox.querySelector('.placeholder');
        if (placeholder) placeholder.remove();

        const input = `保险问卷：年龄 ${formData.age} 岁，年收入 ${formData.income} 元，健康状况：${formData.health_conditions}，保险需求：${formData.insurance_needs}`;
        appendMessage('user', input);

        if (!(await checkBackendHealth())) {
            appendMessage('assistant', '错误：后端服务（http://localhost:8000）未响应，请检查 Uvicorn 是否运行或查看 app.log。');
            closeModal(insuranceFormModal, insuranceFormContent, insuranceFormError);
            isSubmitting = false;
            if (submitBtn) submitBtn.disabled = false;
            return;
        }

        try {
            const response = await callGrokApi(
                `根据用户提供的保险问卷数据：${JSON.stringify(formData)}，请按以下步骤生成个性化保险推荐，使用 Markdown 格式：
### 1. 信息确认
- 确认用户提供的年龄、收入、健康状况、保险需求
- 询问预算范围、风险偏好和家庭状况（如“您的预算范围是多少？是否有家庭成员需要保障？”）
### 2. 初步推荐
- 推荐至少两种保险产品（如寿险、医疗险），说明适合 begyn理由
### 3. 下一步建议
- 提供购买或咨询建议
语气亲切，强调“为您量身定制”。`,
                currentExpert,
                currentSessionId,
                20000
            );
            appendMessage('assistant', response);
            saveChatHistory(input, response, currentExpert);
            updateSessionList();
            closeModal(insuranceFormModal, insuranceFormContent, insuranceFormError);
            awaitingInsuranceClarification = true;
        } catch (error) {
            const errorMessage = `错误：问卷提交失败 - ${error.message}. 请检查后端服务（http://localhost:8000）日志（D:/jiayi/grok3/app.log）或网络连接。`;
            appendMessage('assistant', errorMessage);
            console.error('问卷提交失败:', error);
            if (insuranceFormError) {
                insuranceFormError.textContent = errorMessage;
                insuranceFormError.style.display = 'block';
                gsap.from('#insurance-form-error', { opacity: 0, y: 10, duration: 0.3, ease: 'power2.out' });
            }
            closeModal(insuranceFormModal, insuranceFormContent, insuranceFormError);
        } finally {
            isSubmitting = false;
            if (submitBtn) submitBtn.disabled = false;
        }
    }

    // 提交医疗情况报告
    async function submitMedicalForm(e) {
        e.preventDefault();
        if (isSubmitting || isModalOpening) return;

        isSubmitting = true;
        const submitBtn = document.getElementById('submit-medical-form-btn');
        if (submitBtn) submitBtn.disabled = true;
        if (medicalFormError) medicalFormError.style.display = 'none';

        const formData = {
            age: parseInt(document.getElementById('med-form-age')?.value) || 0,
            gender: document.getElementById('med-form-gender')?.value || '',
            symptoms: document.getElementById('med-form-symptoms')?.value.trim() || '',
            duration: document.getElementById('med-form-duration')?.value.trim() || '',
            history: document.getElementById('med-form-history')?.value.trim() || ''
        };

        if (!formData.age || !formData.gender || !formData.symptoms || !formData.duration || !formData.history) {
            if (medicalFormError) {
                medicalFormError.textContent = '请填写所有字段';
                medicalFormError.style.display = 'block';
                gsap.from('#medical-form-error', { opacity: 0, y: 10, duration: 0.3, ease: 'power2.out' });
            }
            isSubmitting = false;
            if (submitBtn) submitBtn.disabled = false;
            return;
        }

        const placeholder = chatBox.querySelector('.placeholder');
        if (placeholder) placeholder.remove();

        const input = `医疗情况报告：年龄 ${formData.age} 岁，性别 ${formData.gender}，主要症状：${formData.symptoms}，持续时间：${formData.duration}，既往病史：${formData.history}`;
        appendMessage('user', input);

        if (!(await checkBackendHealth())) {
            appendMessage('assistant', '错误：后端服务（http://localhost:8000）未响应，请检查 Uvicorn 是否运行或查看 app.log。');
            closeModal(medicalFormModal, medicalFormContent, medicalFormError);
            isSubmitting = false;
            if (submitBtn) submitBtn.disabled = false;
            return;
        }

        try {
            const response = await callGrokApi(
                `用户医疗情况报告：${JSON.stringify(formData)}。请模拟专业医生问诊流程，使用 Markdown 格式，输出以下结构：
### 1. 症状澄清
- 提出具体问题以澄清症状（如“症状的严重程度如何？是否有伴随症状如发热或恶心？”）
### 2. 可能性排除
- 列出至少两种可能的疾病，并说明排除理由（如“排除急性阑尾炎，因为无右下腹痛”）
### 3. 初步诊断
- 提供可能的诊断，说明依据
### 4. 建议
- 提供治疗建议或进一步检查建议
语气专业但亲切，避免使用过于复杂的医学术语。`,
                currentExpert,
                currentSessionId,
                20000
            );
            appendMessage('assistant', response);
            saveChatHistory(input, response, currentExpert);
            updateSessionList();
            closeModal(medicalFormModal, medicalFormContent, medicalFormError);
        } catch (error) {
            const errorMessage = `错误：报告提交失败 - ${error.message}. 请检查后端服务（http://localhost:8000）日志（D:/jiayi/grok3/app.log）或网络连接。`;
            appendMessage('assistant', errorMessage);
            console.error('报告提交失败:', error);
            if (medicalFormError) {
                medicalFormError.textContent = errorMessage;
                medicalFormError.style.display = 'block';
                gsap.from('#medical-form-error', { opacity: 0, y: 10, duration: 0.3, ease: 'power2.out' });
            }
            closeModal(medicalFormModal, medicalFormContent, medicalFormError);
        } finally {
            isSubmitting = false;
            if (submitBtn) submitBtn.disabled = false;
        }
    }

    // 动态调整输入框高度
    userInput.addEventListener('input', () => {
        userInput.style.height = '120px';
        userInput.style.height = `${Math.min(userInput.scrollHeight, 250)}px`;
    });

    // 调用 Grok API
    async function callGrokApi(userInput, expertType, sessionId, timeout = 20000) {
        try {
            if (!userInput) throw new Error('用户输入为空');
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), timeout);
            const apiHistory = getChatHistory(sessionId).map(msg => ({
                role: msg.role === 'ai' ? 'assistant' : msg.role,
                content: msg.content
            }));
            console.log('发送请求到:', 'http://localhost:8000/api/chat', { userInput, expertType, sessionId });
            const response = await fetch('http://localhost:8000/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    user_input: userInput,
                    expert_type: expertType,
                    session_id: sessionId,
                    history: apiHistory
                }),
                signal: controller.signal
            });
            clearTimeout(timeoutId);
            if (!response.ok) {
                let errorDetail;
                try {
                    const errorData = await response.json();
                    errorDetail = errorData.detail || `HTTP错误！状态: ${response.status}`;
                } catch {
                    errorDetail = `HTTP错误！状态: ${response.status}. 后端服务（http://localhost:8000）可能未正常响应，请检查 Uvicorn 是否运行或查看 D:/jiayi/grok3/app.log。`;
                }
                throw new Error(errorDetail);
            }
            const data = await response.json();
            if (!data.response) {
                throw new Error('响应格式错误：无 response 字段');
            }
            return data.response;
        } catch (error) {
            console.error('API请求失败:', error);
            if (error.name === 'AbortError') {
                throw new Error('请求超时，请检查后端服务（http://localhost:8000）日志（D:/jiayi/grok3/app.log）或网络连接');
            }
            throw new Error(error.message);
        }
    }

    // 添加消息
    function appendMessage(role, content) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}`;
        if (role === 'assistant') {
            messageDiv.innerHTML = marked.parse(content, {
                breaks: true,
                gfm: true
            });
        } else {
            messageDiv.textContent = content;
        }
        chatBox.appendChild(messageDiv);
        chatBox.scrollTo({
            top: chatBox.scrollHeight,
            behavior: 'smooth'
        });
        gsap.from(messageDiv, { opacity: 0, y: 10, duration: 0.3, ease: 'power2.out' });
    }

    // 保存聊天历史
    function saveChatHistory(userInput, response, expertType) {
        let chatHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
        if (!currentSessionId) {
            currentSessionId = Date.now().toString();
        }
        const session = chatHistory.find(s => s.sessionId === currentSessionId);
        if (session) {
            session.history.push({ role: 'user', content: userInput }, { role: 'assistant', content: response });
        } else {
            chatHistory.push({
                sessionId: currentSessionId,
                expert: expertType,
                history: [
                    { role: 'user', content: userInput },
                    { role: 'assistant', content: response }
                ],
                timestamp: new Date().toLocaleString('zh-CN')
            });
        }
        localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
    }

    // 获取聊天历史
    function getChatHistory(sessionId) {
        const chatHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
        const session = chatHistory.find(s => s.sessionId === sessionId);
        return session ? session.history : [];
    }

    // 更新会话列表
    function updateSessionList() {
        const sessionList = document.getElementById('session-list');
        const chatHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
        sessionList.innerHTML = '';
        chatHistory.forEach((session, index) => {
            const li = document.createElement('li');
            const icon = session.expert === 'medical'
                ? '<img src="/images/medical-icon.png" alt="医疗专家" width="24" height="24">'
                : '<img src="/images/insurance-icon.png" alt="保险专家" width="24" height="24">';
            li.innerHTML = `${icon} 会话 ${index + 1}: ${session.expert === 'medical' ? '医疗问诊' : '保险资产配置'} - ${session.timestamp} <span class="session-delete" data-session-id="${session.sessionId}">&times;</span>`;
            li.onclick = (e) => {
                if (e.target.classList.contains('session-delete')) {
                    deleteSession(session.sessionId);
                } else {
                    loadSession(session.sessionId);
                }
            };
            sessionList.appendChild(li);
            gsap.from(li, { opacity: 0, x: -10, duration: 0.3, delay: index * 0.05, ease: 'power2.out' });
        });
    }

    // 删除会话
    function deleteSession(sessionId) {
        let chatHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
        chatHistory = chatHistory.filter(s => s.sessionId !== sessionId);
        localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
        if (currentSessionId === sessionId) {
            startNewSession();
        } else {
            updateSessionList();
        }
    }

    // 加载会话
    function loadSession(sessionId) {
        currentSessionId = sessionId;
        const chatHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
        const session = chatHistory.find(s => s.sessionId === sessionId);
        if (session) {
            currentExpert = session.expert;
            awaitingInsuranceClarification = false;
            updateExpertSelection();
            updateExpertTitle();
            updateFormButtonVisibility();
            chatBox.innerHTML = '';
            session.history.forEach(msg => appendMessage(msg.role, msg.content));
            const listItems = document.querySelectorAll('#session-list li');
            listItems.forEach(item => item.classList.remove('selected'));
            const selectedItem = Array.from(listItems).find(item => item.querySelector('.session-delete').dataset.sessionId === sessionId);
            if (selectedItem) selectedItem.classList.add('selected');
            // 清理并重新绑定事件
            insuranceFormBtn = clearEventListeners(insuranceFormBtn);
            medicalFormBtn = clearEventListeners(medicalFormBtn);
            insuranceFormClose = clearEventListeners(insuranceFormClose);
            medicalFormClose = clearEventListeners(medicalFormClose);
            insuranceFormContent = clearEventListeners(insuranceFormContent);
            medicalFormContent = clearEventListeners(medicalFormContent);
            bindFormEvents();
        }
    }

    // 开始新会话
    function startNewSession() {
        currentSessionId = null;
        awaitingInsuranceClarification = false;
        chatBox.innerHTML = '<div class="placeholder">欢迎开始咨询！请输入您的问题或填写相关问卷。</div>';
        userInput.value = '';
        userInput.style.height = '120px';
        forceCloseModal(insuranceFormModal, insuranceFormContent, insuranceFormError);
        forceCloseModal(medicalFormModal, medicalFormContent, medicalFormError);
        const listItems = document.querySelectorAll('#session-list li');
        listItems.forEach(item => item.classList.remove('selected'));
        gsap.from('.placeholder', { opacity: 0, y: 10, duration: 0.3, ease: 'power2.out' });
        // 清理并重新绑定事件
        insuranceFormBtn = clearEventListeners(insuranceFormBtn);
        medicalFormBtn = clearEventListeners(medicalFormBtn);
        insuranceFormClose = clearEventListeners(insuranceFormClose);
        medicalFormClose = clearEventListeners(medicalFormClose);
        insuranceFormContent = clearEventListeners(insuranceFormContent);
        medicalFormContent = clearEventListeners(medicalFormContent);
        bindFormEvents();
    }
});